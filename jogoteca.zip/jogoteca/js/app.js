/* Jogoteca — roteador por hash e renderização das telas.
   Rotas:
     #/                         Início
     #/catalogo?p=1             Catálogo paginado (20 por página)
     #/busca?q=astro            Busca por trecho do título
     #/jogo/<slug>              Detalhes
     #/jogo/<slug>/acesso       Acesso (simulado)
*/
(function () {
  "use strict";

  const POR_PAGINA = 20;
  const app = document.getElementById("conteudo");

  // ---------- utilidades ----------
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const normalizar = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim();
  const ordenados = [...JOGOS].sort((a, b) => a.titulo.localeCompare(b.titulo, "pt-BR", { sensitivity: "base" }));
  const porSlug = (slug) => JOGOS.find((j) => j.slug === slug);
  const generoCurto = (g) => g.split(" ")[0];

  function capa(jogo, grande = false) {
    return `
      <div class="capa${grande ? " capa--grande" : ""}" style="--tema:${jogo.tema};--destaque:${jogo.destaque}" aria-hidden="true">
        <span class="capa__circulo"></span>
        <span class="capa__bolha"></span>
        ${grande ? "" : '<span class="capa__faixa"></span>'}
        <span class="capa__titulo">${esc(jogo.titulo.toUpperCase())}</span>
      </div>`;
  }

  function card(jogo) {
    return `
      <li>
        <a class="card" href="#/jogo/${jogo.slug}">
          ${capa(jogo)}
          <span class="card__info">
            <span class="card__titulo">${esc(jogo.titulo)}</span>
            <span class="card__genero">${esc(jogo.genero)}</span>
          </span>
        </a>
      </li>`;
  }

  const grade = (lista) => `<ul class="grade" role="list">${lista.map(card).join("")}</ul>`;

  function formBusca(valor = "", rotulo = "Buscar") {
    return `
      <form class="busca" role="search" data-busca>
        <label class="sr-only" for="campo-busca">Buscar por nome ou parte do título</label>
        <svg class="busca__icone" viewBox="0 0 24 24" aria-hidden="true"><path d="M10.5 3a7.5 7.5 0 0 1 5.9 12.1l4.8 4.8-1.4 1.4-4.8-4.8A7.5 7.5 0 1 1 10.5 3zm0 2a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11z"/></svg>
        <input id="campo-busca" name="q" type="search" autocomplete="off" placeholder="Buscar por nome ou parte do título..." value="${esc(valor)}">
        <button class="btn btn--primario" type="submit">${rotulo}</button>
      </form>`;
  }

  // ---------- telas ----------
  function telaInicio() {
    const secoes = SECOES_HOME.map((s) => `
      <section class="secao">
        <div class="secao__cabecalho">
          <h2>${esc(s.titulo)}</h2>
          <p>${esc(s.subtitulo)}</p>
        </div>
        ${grade(s.slugs.map(porSlug).filter(Boolean))}
      </section>`).join("");

    return {
      titulo: "Início",
      html: `
        <section class="hero">
          <div class="hero__texto">
            <p class="sobretitulo">Experiência digital • Catálogo de jogos</p>
            <h1>Descubra seu próximo jogo favorito.</h1>
            <p>Explore títulos em destaque, descubra novidades e navegue por uma coleção de aventuras.</p>
            <div class="acoes">
              <a class="btn btn--primario" href="#/catalogo">Explorar catálogo <span aria-hidden="true">→</span></a>
              <a class="btn btn--claro" href="#/jogo/orbita-zero">Ver jogo em destaque</a>
            </div>
          </div>
          <div class="hero__arte" aria-hidden="true">
            <span class="hero__disco"></span>
            <span class="hero__anel"></span>
            <span class="hero__nucleo"></span>
            <span class="hero__bolha"></span>
            <span class="hero__linha"></span>
          </div>
        </section>
        ${secoes}`
    };
  }

  function paginacao(atual, total, base) {
    if (total <= 1) return "";
    const link = (p, txt, extra = "") => `<a class="pag__item ${extra}" href="${base}${p}" ${p === atual ? 'aria-current="page"' : ""}>${txt}</a>`;
    const desab = (txt) => `<span class="pag__item pag__item--desab" aria-disabled="true">${txt}</span>`;
    let html = atual > 1 ? link(atual - 1, "Anterior") : desab("Anterior");
    for (let p = 1; p <= total; p++) html += link(p, p, p === atual ? "pag__item--ativo" : "");
    html += atual < total ? link(atual + 1, "Próxima") : desab("Próxima");
    return `<nav class="pag" aria-label="Paginação">${html}</nav>`;
  }

  function telaCatalogo(params) {
    const total = Math.ceil(ordenados.length / POR_PAGINA);
    let pagina = parseInt(params.get("p"), 10) || 1;
    pagina = Math.min(Math.max(pagina, 1), total);
    const lista = ordenados.slice((pagina - 1) * POR_PAGINA, pagina * POR_PAGINA);

    return {
      titulo: `Catálogo — página ${pagina}`,
      html: `
        <header class="cabecalho-pagina">
          <h1>Catálogo de jogos</h1>
          <p>${pagina === 1 ? "Explore toda a coleção. Organize, pesquise e encontre sua próxima aventura." : `Página ${pagina} · Continuação alfabética da coleção fictícia`}</p>
        </header>
        ${pagina === 1 ? formBusca() : ""}
        <div class="meta">
          <span>${POR_PAGINA} jogos por página • Ordem alfabética (A–Z)</span>
          <span>Página ${pagina} de ${total} • ${ordenados.length} jogos fictícios</span>
        </div>
        ${grade(lista)}
        ${paginacao(pagina, total, "#/catalogo?p=")}`
    };
  }

  function telaBusca(params) {
    const termo = (params.get("q") || "").trim();
    const n = normalizar(termo);
    const resultados = n ? ordenados.filter((j) => normalizar(j.titulo).includes(n)) : [];

    let corpo;
    if (!termo) {
      corpo = `<p class="vazio">Digite parte do nome de um jogo. Exemplo: <a href="#/busca?q=astro">astro</a>.</p>`;
    } else if (resultados.length === 0) {
      corpo = `<p class="vazio">Nenhum jogo encontrado para “${esc(termo)}”. Tente outro trecho do título.</p>`;
    } else {
      corpo = `
        <div class="meta"><span>${resultados.length} ${resultados.length === 1 ? "jogo encontrado" : "jogos encontrados"} • Os resultados aparecem em ordem alfabética</span></div>
        ${grade(resultados)}`;
    }

    return {
      titulo: termo ? `Busca: ${termo}` : "Buscar jogos",
      html: `
        <header class="cabecalho-pagina">
          <h1>${termo ? "Resultados da busca" : "Buscar jogos"}</h1>
          <p>Pesquisa por trecho do título${termo ? `: “${esc(termo)}”` : ""}.</p>
        </header>
        ${formBusca(termo, "Pesquisar")}
        <div aria-live="polite">${corpo}</div>
        <div class="acoes acoes--rodape"><a class="btn btn--claro" href="#/catalogo">Voltar ao catálogo</a></div>`
    };
  }

  function telaDetalhes(jogo) {
    return {
      titulo: jogo.titulo,
      html: `
        <nav class="migalhas" aria-label="Você está em">
          <a href="#/">Início</a><span aria-hidden="true">/</span>
          <a href="#/catalogo">Catálogo</a><span aria-hidden="true">/</span>
          <span aria-current="page">${esc(jogo.titulo)}</span>
        </nav>
        <article class="detalhe">
          ${capa(jogo, true)}
          <div class="detalhe__info">
            <p class="sobretitulo">${esc(generoCurto(jogo.genero))} • Disponível</p>
            <h1>${esc(jogo.titulo)}</h1>
            <p class="detalhe__descricao">${esc(jogo.descricao)}</p>
            <dl class="ficha">
              <div><dt>Gênero</dt><dd>${esc(jogo.genero)}</dd></div>
              <div><dt>Classificação etária</dt><dd>${esc(jogo.classificacao)}</dd></div>
              <div><dt>Disponibilidade</dt><dd>Disponível</dd></div>
            </dl>
            <div class="acoes">
              <a class="btn btn--primario" href="#/jogo/${jogo.slug}/acesso">Jogar agora <span aria-hidden="true">→</span></a>
              <a class="btn btn--claro" href="#/catalogo">Voltar ao catálogo</a>
            </div>
          </div>
        </article>
        <aside class="aviso">
          <h2>Fluxo demonstrativo</h2>
          <p>A navegação e a abertura do jogo são simuladas. O registro real de acessos depende de uma implementação futura.</p>
        </aside>`
    };
  }

  function telaAcesso(jogo) {
    return {
      titulo: `Acesso — ${jogo.titulo}`,
      html: `
        <header class="cabecalho-pagina">
          <h1>Acesso ao jogo</h1>
          <p>Esta tela simula a abertura do endereço de um jogo pelo navegador.</p>
        </header>
        <section class="palco" style="--destaque:${jogo.destaque}">
          <span class="palco__estrela" aria-hidden="true">✦</span>
          <h2>${esc(jogo.titulo)}</h2>
          <p>Demonstração do fluxo de acesso</p>
        </section>
        <div class="acoes">
          <a class="btn btn--primario" href="#/jogo/${jogo.slug}">Voltar aos detalhes</a>
          <a class="btn btn--claro" href="#/">Ir para a Home</a>
        </div>`
    };
  }

  function telaNaoEncontrada() {
    return {
      titulo: "Página não encontrada",
      html: `
        <header class="cabecalho-pagina">
          <h1>Página não encontrada</h1>
          <p>O endereço que você abriu não existe neste protótipo.</p>
        </header>
        <div class="acoes"><a class="btn btn--primario" href="#/">Ir para a Home</a></div>`
    };
  }

  // ---------- roteador ----------
  function rota() {
    const hash = location.hash.replace(/^#/, "") || "/";
    const [caminho, query = ""] = hash.split("?");
    const params = new URLSearchParams(query);
    const partes = caminho.split("/").filter(Boolean);

    if (partes.length === 0) return { nav: "inicio", tela: telaInicio() };
    if (partes[0] === "catalogo") return { nav: "catalogo", tela: telaCatalogo(params) };
    if (partes[0] === "busca") return { nav: "busca", tela: telaBusca(params) };
    if (partes[0] === "jogo") {
      const jogo = porSlug(partes[1]);
      if (!jogo) return { nav: "", tela: telaNaoEncontrada() };
      if (partes[2] === "acesso") return { nav: "catalogo", tela: telaAcesso(jogo) };
      if (!partes[2]) return { nav: "catalogo", tela: telaDetalhes(jogo) };
    }
    return { nav: "", tela: telaNaoEncontrada() };
  }

  let primeiraCarga = true;
  function render() {
    const { nav, tela } = rota();
    app.innerHTML = tela.html;
    document.title = `${tela.titulo} · Jogoteca`;

    document.querySelectorAll("[data-nav]").forEach((a) => {
      if (a.dataset.nav === nav) a.setAttribute("aria-current", "page");
      else a.removeAttribute("aria-current");
    });

    window.scrollTo(0, 0);
    if (!primeiraCarga) app.focus({ preventScroll: true });
    primeiraCarga = false;
  }

  // Busca: envia para #/busca?q=...
  document.addEventListener("submit", (e) => {
    const form = e.target.closest("[data-busca]");
    if (!form) return;
    e.preventDefault();
    const q = form.q.value.trim();
    location.hash = q ? `#/busca?q=${encodeURIComponent(q)}` : "#/busca";
  });

  window.addEventListener("hashchange", render);
  render();
})();
