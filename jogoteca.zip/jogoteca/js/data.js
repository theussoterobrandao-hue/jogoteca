/* Jogos fictícios do protótipo (os mesmos 24 do Figma).
   tema: cor de fundo da capa | destaque: cor do círculo grande */
const JOGOS = [
  { slug: "astro-arena",       titulo: "Astro Arena",       genero: "Ação",            classificacao: "12 anos", tema: "#0f5c66", destaque: "#ffd166", descricao: "Duelos rápidos em arenas flutuantes no meio de um cinturão de asteroides." },
  { slug: "astro-lab",         titulo: "Astro Lab",         genero: "Estratégia",      classificacao: "Livre",   tema: "#0f5c66", destaque: "#fbe08a", descricao: "Monte um laboratório orbital e pesquise tecnologias para colonizar novos planetas." },
  { slug: "astro-voyage",      titulo: "Astro Voyage",      genero: "Exploração",      classificacao: "Livre",   tema: "#124e66", destaque: "#ffd166", descricao: "Uma viagem tranquila por sistemas solares desconhecidos, catalogando cada descoberta." },
  { slug: "castelo-das-nuvens",titulo: "Castelo das Nuvens",genero: "Estratégia",      classificacao: "10 anos", tema: "#0d6670", destaque: "#fbe08a", descricao: "Defenda um castelo suspenso no céu organizando recursos e aliados." },
  { slug: "circuito-neon",     titulo: "Circuito Neon",     genero: "Corrida",         classificacao: "Livre",   tema: "#0d6670", destaque: "#ffd166", descricao: "Corridas noturnas em pistas iluminadas, com atalhos que mudam a cada volta." },
  { slug: "floresta-luminosa", titulo: "Floresta Luminosa", genero: "Exploração",      classificacao: "Livre",   tema: "#0d6670", destaque: "#fbe08a", descricao: "Explore uma floresta que brilha à noite e descubra os segredos de suas criaturas." },
  { slug: "jardim-de-cristal", titulo: "Jardim de Cristal", genero: "Simulação",       classificacao: "Livre",   tema: "#0f5c66", destaque: "#ffd166", descricao: "Cultive plantas de cristal e transforme um terreno vazio num jardim premiado." },
  { slug: "labirinto-prisma",  titulo: "Labirinto Prisma",  genero: "Quebra-cabeça",   classificacao: "Livre",   tema: "#0d6670", destaque: "#fbe08a", descricao: "Redirecione feixes de luz para abrir passagens num labirinto de espelhos." },
  { slug: "mare-de-neon",      titulo: "Maré de Neon",      genero: "Arcade",          classificacao: "Livre",   tema: "#124e66", destaque: "#ffd166", descricao: "Surfe ondas de luz e acumule pontos num arcade de ritmo acelerado." },
  { slug: "mundo-de-origami",  titulo: "Mundo de Origami",  genero: "Casual",          classificacao: "Livre",   tema: "#0d6670", destaque: "#fbe08a", descricao: "Dobre papéis para criar pontes, barcos e caminhos num mundo feito de origami." },
  { slug: "orbita-zero",       titulo: "Órbita Zero",       genero: "Aventura espacial", classificacao: "10 anos", tema: "#0f5c66", destaque: "#4fd1c5", descricao: "Viaje entre mundos, descubra ruínas cósmicas e explore um universo repleto de mistérios. Um jogo fictício criado para demonstrar o protótipo." },
  { slug: "pixel-rush",        titulo: "Pixel Rush",        genero: "Plataforma",      classificacao: "Livre",   tema: "#0d6670", destaque: "#fbe08a", descricao: "Plataforma clássica em pixel art, com fases curtas e desafios cronometrados." },
  { slug: "portais-do-tempo",  titulo: "Portais do Tempo",  genero: "Aventura",        classificacao: "10 anos", tema: "#0d6670", destaque: "#fbe08a", descricao: "Atravesse portais para diferentes épocas e corrija falhas na linha do tempo." },
  { slug: "rota-astral",       titulo: "Rota Astral",       genero: "Aventura",        classificacao: "10 anos", tema: "#0f5c66", destaque: "#9be7df", descricao: "Trace rotas entre constelações e guie uma nave de carga até o destino." },
  { slug: "ruinas-do-sol",     titulo: "Ruínas do Sol",     genero: "Ação",            classificacao: "12 anos", tema: "#124e66", destaque: "#4fd1c5", descricao: "Enfrente guardiões antigos em templos escondidos sob o deserto." },
  { slug: "saltos-da-lua",     titulo: "Saltos da Lua",     genero: "Plataforma",      classificacao: "Livre",   tema: "#0f5c66", destaque: "#ffd166", descricao: "Pule entre crateras com gravidade reduzida e colete fragmentos lunares." },
  { slug: "torre-esmeralda",   titulo: "Torre Esmeralda",   genero: "Estratégia",      classificacao: "10 anos", tema: "#0d6670", destaque: "#fbe08a", descricao: "Construa andar por andar uma torre defensiva contra ondas de invasores." },
  { slug: "trilha-cosmica",    titulo: "Trilha Cósmica",    genero: "Corrida",         classificacao: "Livre",   tema: "#0f5c66", destaque: "#ffd166", descricao: "Corridas em trilhas espaciais com curvas impossíveis e turbo de cometas." },
  { slug: "vale-das-estrelas", titulo: "Vale das Estrelas", genero: "Aventura",        classificacao: "Livre",   tema: "#0d6670", destaque: "#4fd1c5", descricao: "Acompanhe uma pequena exploradora num vale onde as estrelas caem toda noite." },
  { slug: "vila-dos-ventos",   titulo: "Vila dos Ventos",   genero: "Simulação",       classificacao: "Livre",   tema: "#0f5c66", destaque: "#9be7df", descricao: "Administre uma vila movida a cata-ventos e mantenha todos felizes." },
  { slug: "voo-livre",         titulo: "Voo Livre",         genero: "Aventura",        classificacao: "Livre",   tema: "#0f5c66", destaque: "#fbe08a", descricao: "Plane sobre ilhas flutuantes e descubra caminhos escondidos entre as nuvens." },
  { slug: "xadrez-lunar",      titulo: "Xadrez Lunar",      genero: "Estratégia",      classificacao: "Livre",   tema: "#0d6670", destaque: "#fbe08a", descricao: "Uma variação do xadrez jogada num tabuleiro que muda com as fases da lua." },
  { slug: "ypsilon-quest",     titulo: "Ypsilon Quest",     genero: "Quebra-cabeça",   classificacao: "Livre",   tema: "#0f5c66", destaque: "#ffd166", descricao: "Resolva enigmas lógicos para atravessar um mundo em forma de letra Y." },
  { slug: "zenite-azul",       titulo: "Zênite Azul",       genero: "Ação",            classificacao: "12 anos", tema: "#124e66", destaque: "#ffd166", descricao: "Combates aéreos no ponto mais alto do céu, sobre um oceano sem fim." }
];

/* Seleções da página inicial, como no Figma */
const SECOES_HOME = [
  { titulo: "Jogos em destaque", subtitulo: "Escolhas especiais da plataforma", slugs: ["orbita-zero", "floresta-luminosa", "circuito-neon", "castelo-das-nuvens"] },
  { titulo: "Mais acessados",    subtitulo: "Os favoritos da comunidade",       slugs: ["astro-arena", "pixel-rush", "rota-astral", "labirinto-prisma"] },
  { titulo: "Novidades",         subtitulo: "Os jogos adicionados recentemente", slugs: ["astro-lab", "jardim-de-cristal", "mare-de-neon", "vale-das-estrelas"] }
];
