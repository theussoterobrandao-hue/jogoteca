# Jogoteca — Plataforma Web de Jogos (protótipo acadêmico)

Site feito em HTML, CSS e JavaScript puros, seguindo o protótipo do Figma.
Mobile-first: o layout base é o de celular e se adapta para tablet (≥600px) e desktop (≥900px).

## Como abrir

- **Mais simples:** dê dois cliques em `index.html`.
- **No VS Code (recomendado):** instale a extensão *Live Server*, clique com o botão direito em `index.html` → *Open with Live Server*. A página recarrega sozinha a cada alteração.
- **Testar como celular:** no Chrome, `F12` → ícone de celular (Ctrl+Shift+M) → escolha um aparelho.

## Estrutura

```
index.html        estrutura fixa (topo, menu, barra inferior)
css/styles.css    todo o visual; cores no topo do arquivo (:root)
js/data.js        os 24 jogos e as seções da página inicial
js/app.js         rotas e montagem de cada tela
```

## Telas (rotas)

| Tela | Endereço |
|---|---|
| Início | `#/` |
| Catálogo (20 por página) | `#/catalogo?p=1` |
| Busca | `#/busca?q=astro` |
| Detalhes | `#/jogo/orbita-zero` |
| Acesso (simulado) | `#/jogo/orbita-zero/acesso` |

## Como mexer

- **Adicionar um jogo:** copie uma linha em `js/data.js` e troque os dados. O `slug` precisa ser único e sem acento.
- **Mudar as cores:** edite as variáveis no começo de `css/styles.css`.
- **Mudar os destaques da Home:** edite `SECOES_HOME` em `js/data.js`.

## O que é simulado

Não há back-end. "Jogar agora" leva a uma tela de demonstração, e nada é gravado.
